# vivado-boards

This repository contains the board files used by Vivado to add support for Digilent system boards.
The old folder is for use with Vivado versions 14.4 and below. The new folder covers Vivado 15.x and above

For instructions on how to install these files, the following wiki page can be used.

https://reference.digilentinc.com/vivado:boardfiles
